import React, { useState } from "react";
import axios from "axios";
import "./LoginForm.css";
import robotImg from "../assets/Hai.png";

const LoginForm = () => {
  // State untuk input email dan password
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  // Fungsi saat form disubmit
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        "https://0d2c-36-82-10-190.ngrok-free.app/api/login",
        {
          email: email,
          password: password,
        }
      );
      console.log("Login sukses:", response.data);
    } catch (error) {
      console.error("Login gagal:", error.response?.data || error.message);
    }
  };

  return (
    <div className="login-container">
      <div className="left-panel">
        <h1>
          Selamat Datang <br />
          Kembali!
        </h1>
        <p>
          Siap lanjut belajar tambah-tambahan, pengurangan, dan serunya dunia
          angka?
        </p>
        <img src={robotImg} alt="Robot Ilustrasi" className="Hai mx-auto" />
      </div>
      <div className="right-panel">
        <h2>Sign In</h2>
        <p>
          Ayo lanjut belajar Matematika Dasar dengan <br />
          cara seru dan menyenangkan!
        </p>
        <form onSubmit={handleSubmit}>
          <label>Email</label>
          <input
            type="email"
            placeholder="email@gmail.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />

          <label>Password</label>
          <input
            type="password"
            placeholder="Input Text Here"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />

          <div className="checkbox">
            <div>
              <input className="cek" type="checkbox" id="keep-logged" />
              <label htmlFor="keep-logged"> Tetap login</label>
            </div>
            <a href="#">Lupa Password?</a>
          </div>

          <button type="submit">Sign In</button>
          <button className="google-btn" type="button">
            Masuk dengan Google
          </button>

          <p className="small">
            Belum punya akun? <a href="#">Buat Akun</a>
          </p>
        </form>
      </div>
    </div>
  );
};

export default LoginForm;
