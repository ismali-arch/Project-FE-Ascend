// App.jsx
import React from "react";
import LoginForm from "./components/LoginForm";

function App() {
  return (
    <div>
      <LoginForm />
    </div>
  );
}

export default App;
